# Movie Trailer Website

### Building the web page in TERMINAL
In the Start menu, select "Run...", and type in cmd. This will cause the Windows terminal to open.
Type cd \movie_website_creation_project(directory name) to change directory to your program folder, and hit Enter.
Type entertainer.py to run your program!

### Generating the page in IDLE
Right Click on entertainer.py file and choose edit with IDLE
In the "entertainer.py" window, select Run, Run Module (or press F5) to run your script.
The "Python Shell" window will display the output of your script.
This will take you to the website.
